#!/usr/bin/python
# -*- coding=utf8 -*-
"""
# @Author : YHJ
# @Created Time : 2023-11-15 15:54:07
# @Description : 
"""

# 模块版本
__version__ = "1.0.1"

# 预加载模块
#from .fasta import fasta
#from .fastq import fastq
import matplotlib
import pandas
import numpy


# 初始化配置参数
CONFIG_PARAM = "example"

# 初始化代码
print("This is anamofo package!")
