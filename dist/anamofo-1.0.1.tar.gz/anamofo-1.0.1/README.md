# anamofo
note the python analysis code
